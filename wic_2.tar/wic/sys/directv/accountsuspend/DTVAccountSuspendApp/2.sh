#!/bin/sh
# This is a comment!
echo  "Hi this is somya"        # This is a comment, too!