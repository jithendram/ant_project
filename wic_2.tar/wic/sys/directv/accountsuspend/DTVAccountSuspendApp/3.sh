#!/bin/sh
# This is a comment!
echo  "This is my first program "