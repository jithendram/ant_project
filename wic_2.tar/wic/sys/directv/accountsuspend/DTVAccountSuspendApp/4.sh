#!/bin/sh
# This is a comment!
echo "Its Completed"       # This is a comment, too!